from django.apps import AppConfig


class BookclassConfig(AppConfig):
    name = 'apps.BookType'
